def factorial(num):
    r=1
    for i in range(1,num):
        r *= i
        return r

n = input("De que numero deseas sacar factorial: ")
n = int (n)
print("El factorial de ", n, "es:", factorial(n+1))



